﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ogrenciAdTxt = new System.Windows.Forms.TextBox();
            this.ogrenciSoyadTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ogrenciBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.etutDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.etutDataSet = new WindowsFormsApp2.EtutDataSet();
            this.button1 = new System.Windows.Forms.Button();
            this.ogrenciTableAdapter = new WindowsFormsApp2.EtutDataSetTableAdapters.OgrenciTableAdapter();
            this.buttonSil = new System.Windows.Forms.Button();
            this.ogrenciID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soyadDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dogumtarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayittarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayitbitistarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayitücretDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tcnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sinifseviyeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.etutDataSet1 = new WindowsFormsApp2.EtutDataSet1();
            this.silinenOgrencilerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.silinenOgrencilerTableAdapter = new WindowsFormsApp2.EtutDataSet1TableAdapters.SilinenOgrencilerTableAdapter();
            this.ogrenciIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tcNoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soyadDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sinifSeviyeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dogumTarihiDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telNoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayitTarihiDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayitBitisTarihiDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kayitUcretDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.silinmeTarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.etutDataSet2 = new WindowsFormsApp2.EtutDataSet2();
            this.silinenOdemePlanlariBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.silinenOdemePlanlariTableAdapter = new WindowsFormsApp2.EtutDataSet2TableAdapters.SilinenOdemePlanlariTableAdapter();
            this.planIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ogrenciIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toplamTutarDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aylikTutarDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.planBaslangicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.planBitisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.silinmeTarihiDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.etutDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.etutDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.etutDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silinenOgrencilerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.etutDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silinenOdemePlanlariBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // ogrenciAdTxt
            // 
            this.ogrenciAdTxt.Location = new System.Drawing.Point(15, 33);
            this.ogrenciAdTxt.Name = "ogrenciAdTxt";
            this.ogrenciAdTxt.Size = new System.Drawing.Size(137, 22);
            this.ogrenciAdTxt.TabIndex = 0;
            // 
            // ogrenciSoyadTxt
            // 
            this.ogrenciSoyadTxt.Location = new System.Drawing.Point(170, 33);
            this.ogrenciSoyadTxt.Name = "ogrenciSoyadTxt";
            this.ogrenciSoyadTxt.Size = new System.Drawing.Size(137, 22);
            this.ogrenciSoyadTxt.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "AD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(167, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "SOYAD";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ogrenciID,
            this.adDataGridViewTextBoxColumn,
            this.soyadDataGridViewTextBoxColumn,
            this.dogumtarihiDataGridViewTextBoxColumn,
            this.telnoDataGridViewTextBoxColumn,
            this.adresDataGridViewTextBoxColumn,
            this.kayittarihiDataGridViewTextBoxColumn,
            this.kayitbitistarihiDataGridViewTextBoxColumn,
            this.kayitücretDataGridViewTextBoxColumn,
            this.tcnoDataGridViewTextBoxColumn,
            this.sinifseviyeDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.ogrenciBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.Location = new System.Drawing.Point(12, 70);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1202, 189);
            this.dataGridView1.TabIndex = 4;
            // 
            // ogrenciBindingSource
            // 
            this.ogrenciBindingSource.DataMember = "Ogrenci";
            this.ogrenciBindingSource.DataSource = this.etutDataSetBindingSource;
            // 
            // etutDataSetBindingSource
            // 
            this.etutDataSetBindingSource.DataSource = this.etutDataSet;
            this.etutDataSetBindingSource.Position = 0;
            // 
            // etutDataSet
            // 
            this.etutDataSet.DataSetName = "EtutDataSet";
            this.etutDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(336, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 39);
            this.button1.TabIndex = 5;
            this.button1.Text = "öğrenci ara";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ogrenciTableAdapter
            // 
            this.ogrenciTableAdapter.ClearBeforeFill = true;
            // 
            // buttonSil
            // 
            this.buttonSil.ForeColor = System.Drawing.Color.Red;
            this.buttonSil.Location = new System.Drawing.Point(934, 14);
            this.buttonSil.Name = "buttonSil";
            this.buttonSil.Size = new System.Drawing.Size(280, 39);
            this.buttonSil.TabIndex = 6;
            this.buttonSil.Text = "Seçilen Öğrencileri Sil";
            this.buttonSil.UseVisualStyleBackColor = true;
            this.buttonSil.Click += new System.EventHandler(this.buttonSil_Click_1);
            // 
            // ogrenciID
            // 
            this.ogrenciID.DataPropertyName = "ogrenciID";
            this.ogrenciID.HeaderText = "ogrenciID";
            this.ogrenciID.MinimumWidth = 6;
            this.ogrenciID.Name = "ogrenciID";
            this.ogrenciID.ReadOnly = true;
            this.ogrenciID.Width = 75;
            // 
            // adDataGridViewTextBoxColumn
            // 
            this.adDataGridViewTextBoxColumn.DataPropertyName = "ad";
            this.adDataGridViewTextBoxColumn.HeaderText = "ad";
            this.adDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.adDataGridViewTextBoxColumn.Name = "adDataGridViewTextBoxColumn";
            this.adDataGridViewTextBoxColumn.Width = 90;
            // 
            // soyadDataGridViewTextBoxColumn
            // 
            this.soyadDataGridViewTextBoxColumn.DataPropertyName = "soyad";
            this.soyadDataGridViewTextBoxColumn.HeaderText = "soyad";
            this.soyadDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.soyadDataGridViewTextBoxColumn.Name = "soyadDataGridViewTextBoxColumn";
            this.soyadDataGridViewTextBoxColumn.Width = 90;
            // 
            // dogumtarihiDataGridViewTextBoxColumn
            // 
            this.dogumtarihiDataGridViewTextBoxColumn.DataPropertyName = "dogum_tarihi";
            this.dogumtarihiDataGridViewTextBoxColumn.HeaderText = "dogum_tarihi";
            this.dogumtarihiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dogumtarihiDataGridViewTextBoxColumn.Name = "dogumtarihiDataGridViewTextBoxColumn";
            // 
            // telnoDataGridViewTextBoxColumn
            // 
            this.telnoDataGridViewTextBoxColumn.DataPropertyName = "tel_no";
            this.telnoDataGridViewTextBoxColumn.HeaderText = "tel_no";
            this.telnoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.telnoDataGridViewTextBoxColumn.Name = "telnoDataGridViewTextBoxColumn";
            // 
            // adresDataGridViewTextBoxColumn
            // 
            this.adresDataGridViewTextBoxColumn.DataPropertyName = "adres";
            this.adresDataGridViewTextBoxColumn.HeaderText = "adres";
            this.adresDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.adresDataGridViewTextBoxColumn.Name = "adresDataGridViewTextBoxColumn";
            this.adresDataGridViewTextBoxColumn.Width = 150;
            // 
            // kayittarihiDataGridViewTextBoxColumn
            // 
            this.kayittarihiDataGridViewTextBoxColumn.DataPropertyName = "kayit_tarihi";
            this.kayittarihiDataGridViewTextBoxColumn.HeaderText = "kayit_tarihi";
            this.kayittarihiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kayittarihiDataGridViewTextBoxColumn.Name = "kayittarihiDataGridViewTextBoxColumn";
            // 
            // kayitbitistarihiDataGridViewTextBoxColumn
            // 
            this.kayitbitistarihiDataGridViewTextBoxColumn.DataPropertyName = "kayit_bitis_tarihi";
            this.kayitbitistarihiDataGridViewTextBoxColumn.HeaderText = "kayit_bitis_tarihi";
            this.kayitbitistarihiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kayitbitistarihiDataGridViewTextBoxColumn.Name = "kayitbitistarihiDataGridViewTextBoxColumn";
            // 
            // kayitücretDataGridViewTextBoxColumn
            // 
            this.kayitücretDataGridViewTextBoxColumn.DataPropertyName = "kayit_ücret";
            this.kayitücretDataGridViewTextBoxColumn.HeaderText = "kayit_ücret";
            this.kayitücretDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kayitücretDataGridViewTextBoxColumn.Name = "kayitücretDataGridViewTextBoxColumn";
            this.kayitücretDataGridViewTextBoxColumn.Width = 90;
            // 
            // tcnoDataGridViewTextBoxColumn
            // 
            this.tcnoDataGridViewTextBoxColumn.DataPropertyName = "tc_no";
            this.tcnoDataGridViewTextBoxColumn.HeaderText = "tc_no";
            this.tcnoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tcnoDataGridViewTextBoxColumn.Name = "tcnoDataGridViewTextBoxColumn";
            // 
            // sinifseviyeDataGridViewTextBoxColumn
            // 
            this.sinifseviyeDataGridViewTextBoxColumn.DataPropertyName = "sinif_seviye";
            this.sinifseviyeDataGridViewTextBoxColumn.HeaderText = "sinif_seviye";
            this.sinifseviyeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sinifseviyeDataGridViewTextBoxColumn.Name = "sinifseviyeDataGridViewTextBoxColumn";
            this.sinifseviyeDataGridViewTextBoxColumn.Width = 90;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ogrenciIDDataGridViewTextBoxColumn,
            this.tcNoDataGridViewTextBoxColumn1,
            this.adDataGridViewTextBoxColumn1,
            this.soyadDataGridViewTextBoxColumn1,
            this.sinifSeviyeDataGridViewTextBoxColumn1,
            this.dogumTarihiDataGridViewTextBoxColumn1,
            this.telNoDataGridViewTextBoxColumn1,
            this.adresDataGridViewTextBoxColumn1,
            this.kayitTarihiDataGridViewTextBoxColumn1,
            this.kayitBitisTarihiDataGridViewTextBoxColumn1,
            this.kayitUcretDataGridViewTextBoxColumn,
            this.silinmeTarihiDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.silinenOgrencilerBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(15, 300);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(752, 167);
            this.dataGridView2.TabIndex = 7;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.planIDDataGridViewTextBoxColumn,
            this.ogrenciIDDataGridViewTextBoxColumn1,
            this.toplamTutarDataGridViewTextBoxColumn,
            this.aylikTutarDataGridViewTextBoxColumn,
            this.planBaslangicDataGridViewTextBoxColumn,
            this.planBitisDataGridViewTextBoxColumn,
            this.silinmeTarihiDataGridViewTextBoxColumn1});
            this.dataGridView3.DataSource = this.silinenOdemePlanlariBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(773, 300);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(441, 167);
            this.dataGridView3.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(562, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "SİLİNEN BİLGİLER";
            // 
            // etutDataSet1
            // 
            this.etutDataSet1.DataSetName = "EtutDataSet1";
            this.etutDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // silinenOgrencilerBindingSource
            // 
            this.silinenOgrencilerBindingSource.DataMember = "SilinenOgrenciler";
            this.silinenOgrencilerBindingSource.DataSource = this.etutDataSet1;
            // 
            // silinenOgrencilerTableAdapter
            // 
            this.silinenOgrencilerTableAdapter.ClearBeforeFill = true;
            // 
            // ogrenciIDDataGridViewTextBoxColumn
            // 
            this.ogrenciIDDataGridViewTextBoxColumn.DataPropertyName = "OgrenciID";
            this.ogrenciIDDataGridViewTextBoxColumn.HeaderText = "OgrenciID";
            this.ogrenciIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ogrenciIDDataGridViewTextBoxColumn.Name = "ogrenciIDDataGridViewTextBoxColumn";
            this.ogrenciIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // tcNoDataGridViewTextBoxColumn1
            // 
            this.tcNoDataGridViewTextBoxColumn1.DataPropertyName = "TcNo";
            this.tcNoDataGridViewTextBoxColumn1.HeaderText = "TcNo";
            this.tcNoDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.tcNoDataGridViewTextBoxColumn1.Name = "tcNoDataGridViewTextBoxColumn1";
            this.tcNoDataGridViewTextBoxColumn1.Width = 125;
            // 
            // adDataGridViewTextBoxColumn1
            // 
            this.adDataGridViewTextBoxColumn1.DataPropertyName = "Ad";
            this.adDataGridViewTextBoxColumn1.HeaderText = "Ad";
            this.adDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.adDataGridViewTextBoxColumn1.Name = "adDataGridViewTextBoxColumn1";
            this.adDataGridViewTextBoxColumn1.Width = 125;
            // 
            // soyadDataGridViewTextBoxColumn1
            // 
            this.soyadDataGridViewTextBoxColumn1.DataPropertyName = "Soyad";
            this.soyadDataGridViewTextBoxColumn1.HeaderText = "Soyad";
            this.soyadDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.soyadDataGridViewTextBoxColumn1.Name = "soyadDataGridViewTextBoxColumn1";
            this.soyadDataGridViewTextBoxColumn1.Width = 125;
            // 
            // sinifSeviyeDataGridViewTextBoxColumn1
            // 
            this.sinifSeviyeDataGridViewTextBoxColumn1.DataPropertyName = "SinifSeviye";
            this.sinifSeviyeDataGridViewTextBoxColumn1.HeaderText = "SinifSeviye";
            this.sinifSeviyeDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.sinifSeviyeDataGridViewTextBoxColumn1.Name = "sinifSeviyeDataGridViewTextBoxColumn1";
            this.sinifSeviyeDataGridViewTextBoxColumn1.Width = 125;
            // 
            // dogumTarihiDataGridViewTextBoxColumn1
            // 
            this.dogumTarihiDataGridViewTextBoxColumn1.DataPropertyName = "DogumTarihi";
            this.dogumTarihiDataGridViewTextBoxColumn1.HeaderText = "DogumTarihi";
            this.dogumTarihiDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dogumTarihiDataGridViewTextBoxColumn1.Name = "dogumTarihiDataGridViewTextBoxColumn1";
            this.dogumTarihiDataGridViewTextBoxColumn1.Width = 125;
            // 
            // telNoDataGridViewTextBoxColumn1
            // 
            this.telNoDataGridViewTextBoxColumn1.DataPropertyName = "TelNo";
            this.telNoDataGridViewTextBoxColumn1.HeaderText = "TelNo";
            this.telNoDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.telNoDataGridViewTextBoxColumn1.Name = "telNoDataGridViewTextBoxColumn1";
            this.telNoDataGridViewTextBoxColumn1.Width = 125;
            // 
            // adresDataGridViewTextBoxColumn1
            // 
            this.adresDataGridViewTextBoxColumn1.DataPropertyName = "Adres";
            this.adresDataGridViewTextBoxColumn1.HeaderText = "Adres";
            this.adresDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.adresDataGridViewTextBoxColumn1.Name = "adresDataGridViewTextBoxColumn1";
            this.adresDataGridViewTextBoxColumn1.Width = 125;
            // 
            // kayitTarihiDataGridViewTextBoxColumn1
            // 
            this.kayitTarihiDataGridViewTextBoxColumn1.DataPropertyName = "KayitTarihi";
            this.kayitTarihiDataGridViewTextBoxColumn1.HeaderText = "KayitTarihi";
            this.kayitTarihiDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.kayitTarihiDataGridViewTextBoxColumn1.Name = "kayitTarihiDataGridViewTextBoxColumn1";
            this.kayitTarihiDataGridViewTextBoxColumn1.Width = 125;
            // 
            // kayitBitisTarihiDataGridViewTextBoxColumn1
            // 
            this.kayitBitisTarihiDataGridViewTextBoxColumn1.DataPropertyName = "KayitBitisTarihi";
            this.kayitBitisTarihiDataGridViewTextBoxColumn1.HeaderText = "KayitBitisTarihi";
            this.kayitBitisTarihiDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.kayitBitisTarihiDataGridViewTextBoxColumn1.Name = "kayitBitisTarihiDataGridViewTextBoxColumn1";
            this.kayitBitisTarihiDataGridViewTextBoxColumn1.Width = 125;
            // 
            // kayitUcretDataGridViewTextBoxColumn
            // 
            this.kayitUcretDataGridViewTextBoxColumn.DataPropertyName = "KayitUcret";
            this.kayitUcretDataGridViewTextBoxColumn.HeaderText = "KayitUcret";
            this.kayitUcretDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kayitUcretDataGridViewTextBoxColumn.Name = "kayitUcretDataGridViewTextBoxColumn";
            this.kayitUcretDataGridViewTextBoxColumn.Width = 125;
            // 
            // silinmeTarihiDataGridViewTextBoxColumn
            // 
            this.silinmeTarihiDataGridViewTextBoxColumn.DataPropertyName = "SilinmeTarihi";
            this.silinmeTarihiDataGridViewTextBoxColumn.HeaderText = "SilinmeTarihi";
            this.silinmeTarihiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.silinmeTarihiDataGridViewTextBoxColumn.Name = "silinmeTarihiDataGridViewTextBoxColumn";
            this.silinmeTarihiDataGridViewTextBoxColumn.Width = 125;
            // 
            // etutDataSet2
            // 
            this.etutDataSet2.DataSetName = "EtutDataSet2";
            this.etutDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // silinenOdemePlanlariBindingSource
            // 
            this.silinenOdemePlanlariBindingSource.DataMember = "SilinenOdemePlanlari";
            this.silinenOdemePlanlariBindingSource.DataSource = this.etutDataSet2;
            // 
            // silinenOdemePlanlariTableAdapter
            // 
            this.silinenOdemePlanlariTableAdapter.ClearBeforeFill = true;
            // 
            // planIDDataGridViewTextBoxColumn
            // 
            this.planIDDataGridViewTextBoxColumn.DataPropertyName = "PlanID";
            this.planIDDataGridViewTextBoxColumn.HeaderText = "PlanID";
            this.planIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.planIDDataGridViewTextBoxColumn.Name = "planIDDataGridViewTextBoxColumn";
            this.planIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // ogrenciIDDataGridViewTextBoxColumn1
            // 
            this.ogrenciIDDataGridViewTextBoxColumn1.DataPropertyName = "OgrenciID";
            this.ogrenciIDDataGridViewTextBoxColumn1.HeaderText = "OgrenciID";
            this.ogrenciIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.ogrenciIDDataGridViewTextBoxColumn1.Name = "ogrenciIDDataGridViewTextBoxColumn1";
            this.ogrenciIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // toplamTutarDataGridViewTextBoxColumn
            // 
            this.toplamTutarDataGridViewTextBoxColumn.DataPropertyName = "ToplamTutar";
            this.toplamTutarDataGridViewTextBoxColumn.HeaderText = "ToplamTutar";
            this.toplamTutarDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.toplamTutarDataGridViewTextBoxColumn.Name = "toplamTutarDataGridViewTextBoxColumn";
            this.toplamTutarDataGridViewTextBoxColumn.Width = 125;
            // 
            // aylikTutarDataGridViewTextBoxColumn
            // 
            this.aylikTutarDataGridViewTextBoxColumn.DataPropertyName = "AylikTutar";
            this.aylikTutarDataGridViewTextBoxColumn.HeaderText = "AylikTutar";
            this.aylikTutarDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aylikTutarDataGridViewTextBoxColumn.Name = "aylikTutarDataGridViewTextBoxColumn";
            this.aylikTutarDataGridViewTextBoxColumn.Width = 125;
            // 
            // planBaslangicDataGridViewTextBoxColumn
            // 
            this.planBaslangicDataGridViewTextBoxColumn.DataPropertyName = "PlanBaslangic";
            this.planBaslangicDataGridViewTextBoxColumn.HeaderText = "PlanBaslangic";
            this.planBaslangicDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.planBaslangicDataGridViewTextBoxColumn.Name = "planBaslangicDataGridViewTextBoxColumn";
            this.planBaslangicDataGridViewTextBoxColumn.Width = 125;
            // 
            // planBitisDataGridViewTextBoxColumn
            // 
            this.planBitisDataGridViewTextBoxColumn.DataPropertyName = "PlanBitis";
            this.planBitisDataGridViewTextBoxColumn.HeaderText = "PlanBitis";
            this.planBitisDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.planBitisDataGridViewTextBoxColumn.Name = "planBitisDataGridViewTextBoxColumn";
            this.planBitisDataGridViewTextBoxColumn.Width = 125;
            // 
            // silinmeTarihiDataGridViewTextBoxColumn1
            // 
            this.silinmeTarihiDataGridViewTextBoxColumn1.DataPropertyName = "SilinmeTarihi";
            this.silinmeTarihiDataGridViewTextBoxColumn1.HeaderText = "SilinmeTarihi";
            this.silinmeTarihiDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.silinmeTarihiDataGridViewTextBoxColumn1.Name = "silinmeTarihiDataGridViewTextBoxColumn1";
            this.silinmeTarihiDataGridViewTextBoxColumn1.Width = 125;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1229, 479);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.buttonSil);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ogrenciSoyadTxt);
            this.Controls.Add(this.ogrenciAdTxt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.etutDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.etutDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.etutDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silinenOgrencilerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.etutDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silinenOdemePlanlariBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ogrenciAdTxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private EtutDataSet etutDataSet;
        private System.Windows.Forms.BindingSource etutDataSetBindingSource;
        private System.Windows.Forms.TextBox ogrenciSoyadTxt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource ogrenciBindingSource;
        private EtutDataSetTableAdapters.OgrenciTableAdapter ogrenciTableAdapter;
        private System.Windows.Forms.Button buttonSil;
        private System.Windows.Forms.DataGridViewTextBoxColumn ogrenciID;
        private System.Windows.Forms.DataGridViewTextBoxColumn adDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn soyadDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dogumtarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayittarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayitbitistarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayitücretDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tcnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sinifseviyeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label3;
        private EtutDataSet1 etutDataSet1;
        private System.Windows.Forms.BindingSource silinenOgrencilerBindingSource;
        private EtutDataSet1TableAdapters.SilinenOgrencilerTableAdapter silinenOgrencilerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ogrenciIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tcNoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn adDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn soyadDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sinifSeviyeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dogumTarihiDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn telNoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayitTarihiDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayitBitisTarihiDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn kayitUcretDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn silinmeTarihiDataGridViewTextBoxColumn;
        private EtutDataSet2 etutDataSet2;
        private System.Windows.Forms.BindingSource silinenOdemePlanlariBindingSource;
        private EtutDataSet2TableAdapters.SilinenOdemePlanlariTableAdapter silinenOdemePlanlariTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn planIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ogrenciIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn toplamTutarDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aylikTutarDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn planBaslangicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn planBitisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn silinmeTarihiDataGridViewTextBoxColumn1;
    }
}

